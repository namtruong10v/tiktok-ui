package com.ic2lab.api.musicplayer;

public interface MusicNotificationManager {

    void startNotification();

    void stopNotification();
}
