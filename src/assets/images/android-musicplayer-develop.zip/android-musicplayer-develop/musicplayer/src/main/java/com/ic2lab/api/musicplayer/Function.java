package com.ic2lab.api.musicplayer;

public interface Function<T, R> {

    R apply(T t);
}
