package com.ic2lab.api.musicplayer;

public interface BiConsumer<T, U> {

    void accept(T t, U u);
}