Change Log
==========

## Version 1.0.1

_2017-09-15_

 * Remove unused logs. 
 * Add permissions and MediaButtonReceiver in AndroidManifest.xml.
 * Complete the initial version of README.md.


## Version 1.0.0

_2017-09-13_

Initial release.
